export interface Dealership {
  id: string;
  name: string;
  url: string;
  location: string;
  phone: string;
}

export interface User {
  id: string;
  username: string;
  password?: string;
  email: string;
  role: 'admin' | 'support' | 'user';
}

export interface AuthState {
  user: Omit<User, 'password'> | null;
  users: User[];
  login: (username: string, password: string) => void;
  logout: () => void;
  register: (user: Omit<User, 'id'>) => void;
}

export interface DealershipState {
  dealerships: Dealership[];
  addDealership: (dealership: Omit<Dealership, 'id'>) => void;
  addDealerships: (dealerships: Omit<Dealership, 'id'>[]) => void;
  filterDealerships: (search: string) => Dealership[];
}