import { create } from 'zustand';
import { DealershipState, Dealership } from '../types';

export const useDealershipStore = create<DealershipState>((set, get) => ({
  dealerships: [
    {
      id: '1',
      name: 'Auto Elite',
      url: 'https://autoelite.example.com',
      location: 'São Paulo',
      phone: '(11) 1234-5678',
    },
    {
      id: '2',
      name: 'Car Master',
      url: 'https://carmaster.example.com',
      location: 'Rio de Janeiro',
      phone: '(21) 9876-5432',
    },
  ],
  addDealership: (dealership) => {
    set((state) => ({
      dealerships: [
        ...state.dealerships,
        { ...dealership, id: Math.random().toString(36).substr(2, 9) },
      ],
    }));
  },
  addDealerships: (newDealerships) => {
    set((state) => ({
      dealerships: [
        ...state.dealerships,
        ...newDealerships.map((d) => ({
          ...d,
          id: Math.random().toString(36).substr(2, 9),
        })),
      ],
    }));
  },
  filterDealerships: (search) => {
    const { dealerships } = get();
    if (!search) return dealerships;
    const searchLower = search.toLowerCase();
    return dealerships.filter(
      (d) =>
        d.name.toLowerCase().includes(searchLower) ||
        d.location.toLowerCase().includes(searchLower)
    );
  },
}));