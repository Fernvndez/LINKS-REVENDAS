import { create } from 'zustand';
import { AuthState, User } from '../types';

const initialUsers: User[] = [
  { id: '1', username: 'admin', password: 'admin123', email: 'admin@example.com', role: 'admin' },
  { id: '2', username: 'support', password: 'support123', email: 'support@example.com', role: 'support' },
];

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  users: initialUsers,
  login: (username: string, password: string) => {
    set((state) => {
      const user = state.users.find(
        (u) => u.username === username && u.password === password
      );
      if (user) {
        const { password: _, ...userWithoutPassword } = user;
        return { user: userWithoutPassword };
      }
      throw new Error('Invalid credentials');
    });
  },
  logout: () => set({ user: null }),
  register: (newUser) => {
    set((state) => {
      const existingUser = state.users.find(
        (u) => u.username === newUser.username || u.email === newUser.email
      );
      if (existingUser) {
        throw new Error('Username or email already exists');
      }
      const id = Math.random().toString(36).substr(2, 9);
      const user = { ...newUser, id };
      return {
        users: [...state.users, user],
      };
    });
  },
}));