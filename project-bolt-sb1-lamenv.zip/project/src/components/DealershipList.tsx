import React, { useState } from 'react';
import { Play, Plus, Search } from 'lucide-react';
import { useDealershipStore } from '../store/dealershipStore';
import { useAuthStore } from '../store/authStore';

export function DealershipList() {
  const [search, setSearch] = useState('');
  const { dealerships, filterDealerships } = useDealershipStore();
  const user = useAuthStore((state) => state.user);

  const filteredDealerships = filterDealerships(search);

  const handlePlay = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search dealerships..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
        {(user?.role === 'admin' || user?.role === 'support') && (
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Dealership
          </button>
        )}
      </div>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {filteredDealerships.map((dealership) => (
          <div
            key={dealership.id}
            className="bg-white rounded-lg shadow-md p-4 space-y-2"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">{dealership.name}</h3>
              <button
                onClick={() => handlePlay(dealership.url)}
                className="p-2 text-blue-600 hover:text-blue-700 rounded-full hover:bg-blue-50"
              >
                <Play className="h-5 w-5" />
              </button>
            </div>
            <p className="text-sm text-gray-600">{dealership.location}</p>
            <p className="text-sm text-gray-600">{dealership.phone}</p>
          </div>
        ))}
      </div>
    </div>
  );
}