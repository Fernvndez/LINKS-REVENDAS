import React, { useRef } from 'react';
import { Upload } from 'lucide-react';
import * as XLSX from 'xlsx';
import { useDealershipStore } from '../../store/dealershipStore';
import { Dealership } from '../../types';

export function ExcelImport() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const addDealerships = useDealershipStore((state) => state.addDealerships);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target?.result as ArrayBuffer);
      const workbook = XLSX.read(data, { type: 'array' });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      const dealerships = jsonData.map((row: any) => ({
        name: row.name || '',
        url: row.url || '',
        location: row.location || '',
        phone: row.phone || '',
      }));

      addDealerships(dealerships as Omit<Dealership, 'id'>[]);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="flex items-center gap-2">
      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xls"
        onChange={handleFileUpload}
        className="hidden"
      />
      <button
        onClick={() => fileInputRef.current?.click()}
        className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
      >
        <Upload className="h-4 w-4 mr-2" />
        Import Excel
      </button>
    </div>
  );
}