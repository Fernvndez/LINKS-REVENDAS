import React, { useState } from 'react';
import { Search, Plus } from 'lucide-react';
import { useDealershipStore } from '../../store/dealershipStore';
import { useAuthStore } from '../../store/authStore';
import { DealershipCard } from './DealershipCard';
import { AddDealershipForm } from './AddDealershipForm';

export function DealershipList() {
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const { filterDealerships } = useDealershipStore();
  const user = useAuthStore((state) => state.user);

  const filteredDealerships = filterDealerships(search);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 flex-wrap">
        <div className="flex-1 min-w-[200px]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search dealerships..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
            />
          </div>
        </div>
        {(user?.role === 'admin' || user?.role === 'support') && (
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            {showAddForm ? 'Hide Form' : 'Add Dealership'}
          </button>
        )}
      </div>

      {showAddForm && (user?.role === 'admin' || user?.role === 'support') && (
        <AddDealershipForm />
      )}

      <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {filteredDealerships.map((dealership) => (
          <DealershipCard key={dealership.id} dealership={dealership} />
        ))}
      </div>

      {filteredDealerships.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No dealerships found</p>
        </div>
      )}
    </div>
  );
}