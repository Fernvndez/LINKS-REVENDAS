import React from 'react';
import { Play } from 'lucide-react';
import { Dealership } from '../../types';

interface DealershipCardProps {
  dealership: Dealership;
}

export function DealershipCard({ dealership }: DealershipCardProps) {
  const handlePlay = () => {
    window.open(dealership.url, '_blank');
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 space-y-2 hover:shadow-lg transition-shadow duration-200">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">{dealership.name}</h3>
        <button
          onClick={handlePlay}
          className="p-2 text-blue-600 hover:text-blue-700 rounded-full hover:bg-blue-50 transition-colors duration-200"
          title="Open dealership link"
        >
          <Play className="h-5 w-5" />
        </button>
      </div>
      <div className="space-y-1">
        <p className="text-sm text-gray-600 flex items-center">
          <span className="font-medium">Location:</span>
          <span className="ml-2">{dealership.location}</span>
        </p>
        <p className="text-sm text-gray-600 flex items-center">
          <span className="font-medium">Phone:</span>
          <span className="ml-2">{dealership.phone}</span>
        </p>
      </div>
    </div>
  );
}