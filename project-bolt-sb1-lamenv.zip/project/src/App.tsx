import React, { useState } from 'react';
import { useAuthStore } from './store/authStore';
import { LoginForm } from './components/auth/LoginForm';
import { RegisterForm } from './components/auth/RegisterForm';
import { DealershipList } from './components/dealership/DealershipList';
import { LogOut, UserPlus } from 'lucide-react';

function App() {
  const { user, logout } = useAuthStore();
  const [showRegister, setShowRegister] = useState(false);

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
          <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
            LINKS REVENDAS
          </h1>
          
          {showRegister ? (
            <>
              <RegisterForm onSuccess={() => setShowRegister(false)} />
              <button
                onClick={() => setShowRegister(false)}
                className="mt-4 w-full text-center text-sm text-gray-600 hover:text-gray-800"
              >
                Already have an account? Login
              </button>
            </>
          ) : (
            <>
              <LoginForm />
              <button
                onClick={() => setShowRegister(true)}
                className="mt-4 w-full flex items-center justify-center gap-2 text-sm text-gray-600 hover:text-gray-800"
              >
                <UserPlus className="h-4 w-4" />
                Create new account
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900">
              LINKS REVENDAS
            </h1>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">
                {user.username} ({user.role})
              </span>
              <button
                onClick={logout}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-red-600 hover:bg-red-700 transition-colors duration-200"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <DealershipList />
      </main>
    </div>
  );
}

export default App;